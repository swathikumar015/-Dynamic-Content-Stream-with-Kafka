import sqlite3
from datetime import datetime
from collections import defaultdict

def check_database(db_path='streaming_system.db'):
    """Enhanced database checker with detailed analytics"""
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("🔍 Kafka Streaming Database Analysis")
        print("=" * 70)
        
        # 1. TOPICS OVERVIEW
        print("\n📊 TOPICS OVERVIEW:")
        print("-" * 70)
        
        cursor.execute("SELECT status, COUNT(*) FROM topics GROUP BY status")
        status_counts = cursor.fetchall()
        
        for status, count in status_counts:
            print(f"  {status.upper()}: {count} topic(s)")
        
        # 2. TOPICS BY STATUS
        print("\n📋 TOPICS BY STATUS:")
        print("-" * 70)
        
        for status in ['pending', 'approved', 'active', 'rejected']:
            cursor.execute("""
                SELECT id, name, description, created_at 
                FROM topics 
                WHERE status = ? 
                ORDER BY created_at DESC
            """, (status,))
            topics = cursor.fetchall()
            
            if topics:
                print(f"\n  🏷️  {status.upper()} ({len(topics)}):")
                for topic_id, name, desc, created in topics:
                    desc_short = (desc[:40] + '...') if desc and len(desc) > 40 else (desc or 'No description')
                    print(f"     #{topic_id:2d} | {name:15s} | {desc_short:45s} | {created}")
        
        # 3. USER SUBSCRIPTIONS
        print("\n👥 USER SUBSCRIPTIONS:")
        print("-" * 70)
        
        cursor.execute("""
            SELECT 
                us.id,
                us.user_id,
                t.name as topic_name,
                t.status as topic_status,
                us.subscribed_at
            FROM user_subscriptions us
            JOIN topics t ON us.topic_id = t.id
            ORDER BY us.user_id, us.subscribed_at DESC
        """)
        subscriptions = cursor.fetchall()
        
        if subscriptions:
            print(f"\n  Total Subscriptions: {len(subscriptions)}")
            print()
            
            # Group by user
            user_subs = defaultdict(list)
            for sub_id, user_id, topic_name, topic_status, subscribed_at in subscriptions:
                user_subs[user_id].append({
                    'id': sub_id,
                    'topic': topic_name,
                    'status': topic_status,
                    'time': subscribed_at
                })
            
            for user_id in sorted(user_subs.keys()):
                print(f"  👤 {user_id}:")
                for sub in user_subs[user_id]:
                    status_icon = "✅" if sub['status'] == 'active' else "⏸️"
                    print(f"     {status_icon} {sub['topic']:15s} [{sub['status']:8s}] - since {sub['time']}")
                print()
        else:
            print("  ⚠️  No subscriptions found")
        
        # 4. SUBSCRIPTION STATISTICS
        print("\n📈 SUBSCRIPTION STATISTICS:")
        print("-" * 70)
        
        # Most popular topics
        cursor.execute("""
            SELECT 
                t.name,
                t.status,
                COUNT(us.id) as subscriber_count
            FROM topics t
            LEFT JOIN user_subscriptions us ON t.id = us.topic_id
            GROUP BY t.id
            HAVING subscriber_count > 0
            ORDER BY subscriber_count DESC
            LIMIT 5
        """)
        popular_topics = cursor.fetchall()
        
        if popular_topics:
            print("\n  🏆 Most Popular Topics:")
            for topic_name, status, count in popular_topics:
                print(f"     {topic_name:20s} - {count} subscriber(s) [{status}]")
        
        # Users by subscription count
        cursor.execute("""
            SELECT 
                user_id,
                COUNT(*) as topic_count
            FROM user_subscriptions
            GROUP BY user_id
            ORDER BY topic_count DESC
        """)
        active_users = cursor.fetchall()
        
        if active_users:
            print("\n  👥 Most Active Users:")
            for user_id, count in active_users:
                print(f"     {user_id:20s} - {count} subscription(s)")
        
        # 5. ACTIVE TOPICS WITHOUT SUBSCRIBERS
        print("\n⚠️  ACTIVE TOPICS WITHOUT SUBSCRIBERS:")
        print("-" * 70)
        
        cursor.execute("""
            SELECT 
                t.id,
                t.name,
                t.description
            FROM topics t
            LEFT JOIN user_subscriptions us ON t.id = us.topic_id
            WHERE t.status = 'active' AND us.id IS NULL
            ORDER BY t.created_at DESC
        """)
        unsubscribed = cursor.fetchall()
        
        if unsubscribed:
            print(f"\n  Found {len(unsubscribed)} active topic(s) with no subscribers:")
            for topic_id, name, desc in unsubscribed:
                desc_short = (desc[:50] + '...') if desc and len(desc) > 50 else (desc or 'No description')
                print(f"     #{topic_id:2d} | {name:15s} | {desc_short}")
        else:
            print("\n  ✅ All active topics have at least one subscriber!")
        
        # 6. PENDING TOPICS
        cursor.execute("SELECT COUNT(*) FROM topics WHERE status = 'pending'")
        pending_count = cursor.fetchone()[0]
        
        if pending_count > 0:
            print(f"\n⏳ PENDING APPROVALS:")
            print("-" * 70)
            print(f"  ⚠️  {pending_count} topic(s) waiting for admin approval")
        
        # 7. DATABASE INFO
        print("\n💾 DATABASE INFO:")
        print("-" * 70)
        
        cursor.execute("SELECT COUNT(*) FROM topics")
        total_topics = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM user_subscriptions")
        total_subs = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT user_id) FROM user_subscriptions")
        unique_users = cursor.fetchone()[0]
        
        print(f"  Total Topics: {total_topics}")
        print(f"  Total Subscriptions: {total_subs}")
        print(f"  Unique Users: {unique_users}")
        print(f"  Database: {db_path}")
        
        # 8. RECENT ACTIVITY
        print("\n🕒 RECENT ACTIVITY:")
        print("-" * 70)
        
        cursor.execute("""
            SELECT 
                'Topic Created' as activity_type,
                name as item,
                created_at as time
            FROM topics
            ORDER BY created_at DESC
            LIMIT 3
        """)
        recent_topics = cursor.fetchall()
        
        cursor.execute("""
            SELECT 
                'Subscription' as activity_type,
                user_id || ' -> ' || (SELECT name FROM topics WHERE id = topic_id) as item,
                subscribed_at as time
            FROM user_subscriptions
            ORDER BY subscribed_at DESC
            LIMIT 3
        """)
        recent_subs = cursor.fetchall()
        
        all_recent = recent_topics + recent_subs
        all_recent.sort(key=lambda x: x[2], reverse=True)
        
        print("\n  Last 5 activities:")
        for activity_type, item, time in all_recent[:5]:
            print(f"     [{time}] {activity_type}: {item}")
        
        print("\n" + "=" * 70)
        print("✅ Database analysis complete!")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Database error: {e}")
    except Exception as e:
        print(f"❌ Error: {e}")

def check_specific_user(db_path='streaming_system.db', user_id=None):
    """Check subscriptions for a specific user"""
    
    if not user_id:
        user_id = input("Enter user ID to check: ").strip()
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print(f"\n🔍 Subscriptions for user: {user_id}")
        print("=" * 70)
        
        cursor.execute("""
            SELECT 
                t.name,
                t.status,
                t.description,
                us.subscribed_at
            FROM user_subscriptions us
            JOIN topics t ON us.topic_id = t.id
            WHERE us.user_id = ?
            ORDER BY us.subscribed_at DESC
        """, (user_id,))
        
        subscriptions = cursor.fetchall()
        
        if subscriptions:
            print(f"\n  Found {len(subscriptions)} subscription(s):\n")
            for topic_name, status, desc, subscribed_at in subscriptions:
                status_icon = "✅" if status == 'active' else "⏸️" if status == 'pending' else "❌"
                print(f"  {status_icon} {topic_name}")
                print(f"     Status: {status}")
                print(f"     Description: {desc or 'N/A'}")
                print(f"     Subscribed: {subscribed_at}")
                print()
        else:
            print(f"  ⚠️  No subscriptions found for user '{user_id}'")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Database error: {e}")

def check_specific_topic(db_path='streaming_system.db', topic_name=None):
    """Check who is subscribed to a specific topic"""
    
    if not topic_name:
        topic_name = input("Enter topic name to check: ").strip()
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print(f"\n🔍 Subscribers for topic: {topic_name}")
        print("=" * 70)
        
        # Get topic info
        cursor.execute("SELECT id, status, description, created_at FROM topics WHERE name = ?", (topic_name,))
        topic_info = cursor.fetchone()
        
        if not topic_info:
            print(f"  ❌ Topic '{topic_name}' not found in database")
            conn.close()
            return
        
        topic_id, status, desc, created_at = topic_info
        
        print(f"\n  📋 Topic Info:")
        print(f"     Name: {topic_name}")
        print(f"     Status: {status}")
        print(f"     Description: {desc or 'N/A'}")
        print(f"     Created: {created_at}")
        
        # Get subscribers
        cursor.execute("""
            SELECT user_id, subscribed_at
            FROM user_subscriptions
            WHERE topic_id = ?
            ORDER BY subscribed_at DESC
        """, (topic_id,))
        
        subscribers = cursor.fetchall()
        
        print(f"\n  👥 Subscribers ({len(subscribers)}):")
        if subscribers:
            for user_id, subscribed_at in subscribers:
                print(f"     • {user_id} (since {subscribed_at})")
        else:
            print("     ⚠️  No subscribers yet")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"❌ Database error: {e}")

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == '--user':
            user_id = sys.argv[2] if len(sys.argv) > 2 else None
            check_specific_user(user_id=user_id)
        elif sys.argv[1] == '--topic':
            topic_name = sys.argv[2] if len(sys.argv) > 2 else None
            check_specific_topic(topic_name=topic_name)
        else:
            print("Usage:")
            print("  python3 check_subscriptions.py              # Full analysis")
            print("  python3 check_subscriptions.py --user USER   # Check specific user")
            print("  python3 check_subscriptions.py --topic TOPIC # Check specific topic")
    else:
        check_database()