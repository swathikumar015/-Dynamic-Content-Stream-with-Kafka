#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

if [ -z "$1" ]; then
    echo "Usage: ./create_topic.sh <topic-name> [partitions] [replication-factor]"
    echo "Example: ./create_topic.sh my-topic 3 1"
    exit 1
fi

TOPIC_NAME=$1
PARTITIONS=${2:-1}
REPLICATION=${3:-1}

echo "Creating topic: $TOPIC_NAME"
bin/kafka-topics.sh --create \
    --bootstrap-server localhost:9092 \
    --topic $TOPIC_NAME \
    --partitions $PARTITIONS \
    --replication-factor $REPLICATION

echo "Topic created successfully!"