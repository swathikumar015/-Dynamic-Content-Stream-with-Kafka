import sqlite3
import threading
from datetime import datetime
import socket

class DistributedDatabaseManager:
    def __init__(self, db_path="streaming_system.db", host='172.25.119.229', db_port=5432):
        self.db_path = db_path
        self.host = host
        self.lock = threading.Lock()
        self.init_database()
        print(f"📊 Database initialized on {host}")
    
    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS topics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approved_at TIMESTAMP NULL,
                kafka_created BOOLEAN DEFAULT FALSE,
                producer_node TEXT,
                created_by TEXT DEFAULT 'admin'
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                topic_id INTEGER NOT NULL,
                subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                consumer_node TEXT,
                FOREIGN KEY (topic_id) REFERENCES topics (id),
                UNIQUE(user_id, topic_id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_nodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                node_type TEXT NOT NULL,
                node_ip TEXT NOT NULL,
                node_port INTEGER,
                status TEXT DEFAULT 'active',
                last_heartbeat TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(node_type, node_ip)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def register_node(self, node_type, node_ip, node_port):
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            try:
                cursor.execute('''
                    INSERT OR REPLACE INTO system_nodes 
                    (node_type, node_ip, node_port, status, last_heartbeat)
                    VALUES (?, ?, ?, 'active', CURRENT_TIMESTAMP)
                ''', (node_type, node_ip, node_port))
                conn.commit()
                return True
            except Exception as e:
                print(f"Error registering node: {e}")
                return False
            finally:
                conn.close()
    
    def add_topic(self, name, description="", producer_node=""):
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            try:
                cursor.execute(
                    "INSERT INTO topics (name, description, producer_node) VALUES (?, ?, ?)",
                    (name, description, producer_node)
                )
                conn.commit()
                return True
            except sqlite3.IntegrityError:
                return False
            finally:
                conn.close()
    
    def get_pending_topics(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM topics WHERE status = 'pending'")
        topics = cursor.fetchall()
        conn.close()
        return topics
    
    def get_approved_topics(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM topics WHERE status = 'approved' AND kafka_created = FALSE")
        topics = cursor.fetchall()
        conn.close()
        return topics
    
    def get_active_topics(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM topics WHERE status = 'active' AND kafka_created = TRUE")
        topics = cursor.fetchall()
        conn.close()
        return topics
    
    def update_topic_status(self, topic_id, status):
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if status == 'approved':
                cursor.execute(
                    "UPDATE topics SET status = ?, approved_at = ? WHERE id = ?",
                    (status, datetime.now(), topic_id)
                )
            elif status == 'active':
                cursor.execute(
                    "UPDATE topics SET status = ?, kafka_created = TRUE WHERE id = ?",
                    (status, topic_id)
                )
            else:
                cursor.execute(
                    "UPDATE topics SET status = ? WHERE id = ?",
                    (status, topic_id)
                )
            
            conn.commit()
            conn.close()
            return True

    def mark_topic_as_kafka_created(self, topic_id):
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE topics SET kafka_created = TRUE WHERE id = ?",
                (topic_id,)
            )
            conn.commit()
            conn.close()
    
    def subscribe_user(self, user_id, topic_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO user_subscriptions (user_id, topic_id) VALUES (?, ?)",
                (user_id, topic_id)
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()
    
    def unsubscribe_user(self, user_id, topic_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM user_subscriptions WHERE user_id = ? AND topic_id = ?",
            (user_id, topic_id)
        )
        conn.commit()
        conn.close()
        return True
    
    def get_user_subscriptions(self, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.* FROM topics t
            JOIN user_subscriptions us ON t.id = us.topic_id
            WHERE us.user_id = ? AND t.status = 'active' AND t.kafka_created = TRUE
        ''', (user_id,))
        subscriptions = cursor.fetchall()
        conn.close()
        return subscriptions
    
    def get_all_subscriptions(self):
        """Get all user subscriptions with topic details"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT u.user_id, t.name as topic_name, t.description 
            FROM user_subscriptions u
            JOIN topics t ON u.topic_id = t.id
            WHERE t.status = 'active'
        ''')
        subscriptions = cursor.fetchall()
        conn.close()
        return subscriptions
    
    def get_kafka_broker_info(self):
        """Get Kafka broker information from registered nodes"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT node_ip, node_port FROM system_nodes WHERE node_type = 'kafka' AND status = 'active'")
        kafka_nodes = cursor.fetchall()
        conn.close()
        
        if kafka_nodes:
            return kafka_nodes[0]  # Return first active Kafka node
        return None

    # Add these missing methods that were in the original DatabaseManager
    def get_all_topics(self):
        """Get all topics regardless of status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM topics")
        topics = cursor.fetchall()
        conn.close()
        return topics

    def get_topic_by_name(self, name):
        """Get topic by name"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM topics WHERE name = ?", (name,))
        topic = cursor.fetchone()
        conn.close()
        return topic

    def delete_topic(self, topic_id):
        """Delete a topic"""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            try:
                # First delete subscriptions
                cursor.execute("DELETE FROM user_subscriptions WHERE topic_id = ?", (topic_id,))
                # Then delete topic
                cursor.execute("DELETE FROM topics WHERE id = ?", (topic_id,))
                conn.commit()
                return True
            except Exception as e:
                print(f"Error deleting topic: {e}")
                return False
            finally:
                conn.close()