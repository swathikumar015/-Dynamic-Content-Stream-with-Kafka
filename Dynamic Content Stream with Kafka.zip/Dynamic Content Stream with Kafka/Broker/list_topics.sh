#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

echo "Listing all topics:"
bin/kafka-topics.sh --list --bootstrap-server localhost:9092