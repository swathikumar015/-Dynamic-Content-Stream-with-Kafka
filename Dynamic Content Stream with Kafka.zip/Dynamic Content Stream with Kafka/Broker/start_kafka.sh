#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

echo "Starting Zookeeper..."
bin/zookeeper-server-start.sh config/zookeeper.properties > /tmp/zookeeper.log 2>&1 &
sleep 10

echo "Starting Kafka Server..."
bin/kafka-server-start.sh config/server.properties > /tmp/kafka.log 2>&1 &
sleep 10

echo "Kafka is starting... Check status with: jps"
WSL_IP=$(ip addr show eth0 | grep "inet\b" | awk '{print $2}' | cut -d/ -f1)
echo "Your Kafka Broker: $WSL_IP:9092"