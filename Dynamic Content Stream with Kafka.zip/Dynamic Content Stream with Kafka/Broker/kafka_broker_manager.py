import subprocess
import time
import requests
import socket
import threading
import logging
from kafka import KafkaAdminClient
from kafka.admin import NewTopic
from kafka.errors import TopicAlreadyExistsError

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class KafkaBroker:
    def __init__(self, admin_host='172.25.119.229', admin_port=5000, kafka_port=9092):  # FIXED: __init__
        self.admin_host = admin_host
        self.admin_port = admin_port
        self.kafka_port = kafka_port
        self.broker_ip = self.get_local_ip()
        self.running = True
        self.admin_client = None
        
        logger.info(f"🚀 Kafka Broker Manager Initialized on {self.broker_ip}")
        logger.info(f"🔗 Admin Panel: {self.admin_host}:{self.admin_port}")
        
    def get_local_ip(self):
        """Get the local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except:
            return "127.0.0.1"
    
    def initialize_kafka(self):
        """Initialize Kafka admin client"""
        try:
            self.admin_client = KafkaAdminClient(
                bootstrap_servers=f'{self.broker_ip}:{self.kafka_port}',
                client_id='kafka_broker_manager'
            )
            
            # Test connection by listing topics
            topics = self.admin_client.list_topics()
            logger.info(f"✅ Kafka is healthy - Found {len(topics)} topics")
            
            # Try to get cluster metadata (handle different Kafka versions)
            try:
                cluster_metadata = self.admin_client.describe_cluster()
                if hasattr(cluster_metadata, 'brokers') and cluster_metadata.brokers:
                    logger.info(f"✅ Broker ID: {cluster_metadata.brokers[0].nodeId}")
                if hasattr(cluster_metadata, 'cluster_id'):
                    logger.info(f"✅ Cluster ID: {cluster_metadata.cluster_id}")
            except Exception as e:
                logger.info(f"ℹ️ Could not get cluster metadata (Kafka version difference): {e}")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to connect to Kafka: {e}")
            return False
    
    def register_with_admin(self):
        """Register this Kafka broker with the admin panel"""
        max_retries = 10
        for attempt in range(max_retries):
            try:
                response = requests.post(
                    f"http://{self.admin_host}:{self.admin_port}/api/register_node",
                    json={
                        'node_type': 'kafka',
                        'node_ip': self.broker_ip,
                        'node_port': self.kafka_port
                    },
                    timeout=10
                )
                
                if response.status_code == 200:
                    data = response.json()
                    if data.get('status') == 'success':
                        logger.info("✅ Successfully registered Kafka broker with admin panel")
                        return True
                    else:
                        logger.warning(f"⚠️ Registration failed: {data.get('message', 'Unknown error')}")
                else:
                    logger.warning(f"⚠️ Registration attempt {attempt + 1} failed with status {response.status_code}")
                    
            except requests.exceptions.ConnectionError as e:
                logger.error(f"❌ Cannot connect to admin panel (attempt {attempt + 1}/10): {e}")
            except requests.exceptions.Timeout:
                logger.error(f"❌ Admin panel timeout (attempt {attempt + 1}/10)")
            except Exception as e:
                logger.error(f"❌ Unexpected error during registration (attempt {attempt + 1}/10): {e}")
            
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff
                logger.info(f"⏳ Retrying in {wait_time} seconds...")
                time.sleep(wait_time)
        
        logger.error("❌ Failed to register with admin panel after multiple attempts")
        return False
    
    def get_approved_topics(self):
        """Get approved topics from admin panel"""
        try:
            response = requests.get(
                f"http://{self.admin_host}:{self.admin_port}/api/topics",
                timeout=5
            )
            if response.status_code == 200:
                data = response.json()
                return data.get('approved', [])
        except Exception as e:
            logger.error(f"❌ Failed to get topics from admin: {e}")
        return []
    
    def create_topic_in_kafka(self, topic_name, partitions=1, replication=1):
        """Create a topic in Kafka"""
        try:
            topic = NewTopic(
                name=topic_name,
                num_partitions=partitions,
                replication_factor=replication
            )
            self.admin_client.create_topics([topic])
            logger.info(f"✅ Created topic: {topic_name}")
            return True
            
        except TopicAlreadyExistsError:
            logger.info(f"ℹ️ Topic already exists: {topic_name}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to create topic {topic_name}: {e}")
            return False
    
    def topic_monitor_thread(self):
        """Monitor for approved topics and create them in Kafka"""
        logger.info("👀 Topic Monitor Thread started")
        created_topics = set()
        
        while self.running:
            try:
                # Get current topics in Kafka
                current_kafka_topics = set(self.admin_client.list_topics())
                
                # Get approved topics from admin
                approved_topics = self.get_approved_topics()
                
                for topic in approved_topics:
                    topic_name = topic['name']
                    
                    if topic_name not in created_topics:
                        if self.create_topic_in_kafka(topic_name):
                            created_topics.add(topic_name)
                            logger.info(f"🎉 Successfully processed approved topic: {topic_name}")
                
                # Update created topics with any new topics in Kafka
                created_topics.update(current_kafka_topics)
                
                time.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"❌ Error in topic monitor: {e}")
                time.sleep(5)
    
    def broker_metrics_thread(self):
        """Thread to log broker metrics"""
        logger.info("📊 Broker Metrics Thread started")
        
        while self.running:
            try:
                topics = self.admin_client.list_topics()
                # Filter out internal topics (those starting with __)
                managed_topics = [t for t in topics if not t.startswith('__')]
                
                logger.info(f"📈 Broker Metrics - Total Topics: {len(topics)}, Managed Topics: {len(managed_topics)}")
                if managed_topics:
                    logger.info(f"📋 Current topics: {managed_topics}")
                
                time.sleep(30)  # Log every 30 seconds
                
            except Exception as e:
                logger.error(f"❌ Error in metrics thread: {e}")
                time.sleep(10)
    
    def start(self):
        """Start the Kafka broker management"""
        logger.info("🚀 Starting Kafka Broker Management...")
        
        # Step 1: Initialize Kafka connection
        if not self.initialize_kafka():
            logger.error("❌ Cannot start without Kafka connection")
            return
        
        # Step 2: Register with admin panel
        if not self.register_with_admin():
            logger.warning("⚠️ Starting without admin panel registration")
            # Continue anyway - the system will try to reconnect periodically
        
        # Step 3: Start monitoring threads
        monitor_thread = threading.Thread(target=self.topic_monitor_thread, daemon=True)
        metrics_thread = threading.Thread(target=self.broker_metrics_thread, daemon=True)
        
        monitor_thread.start()
        metrics_thread.start()
        
        logger.info("✅ Kafka Broker Management started successfully!")
        
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("\n🛑 Shutting down Kafka broker manager...")
            self.running = False
        finally:
            if self.admin_client:
                self.admin_client.close()
                logger.info("✅ Kafka admin client closed")

if __name__ == '__main__':
    # Update with your actual admin node IP
    broker = KafkaBroker(admin_host='172.25.119.229')  # Your admin panel IP
    broker.start()