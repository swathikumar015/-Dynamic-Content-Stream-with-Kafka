#!/bin/bash

echo "🚀 Installing Apache Kafka on $(hostname -I)"

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Java
sudo apt-get install -y openjdk-11-jdk

# Set Java environment
echo "JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64" | sudo tee -a /etc/environment
source /etc/environment

# Download Kafka
cd /tmp
wget https://downloads.apache.org/kafka/3.4.0/kafka_2.13-3.4.0.tgz

# Extract Kafka
sudo tar -xzf kafka_2.13-3.4.0.tgz -C /opt/
sudo mv /opt/kafka_2.13-3.4.0 /opt/kafka

# Create Kafka user
sudo useradd kafka -m
sudo usermod -aG sudo kafka
sudo chown -R kafka:kafka /opt/kafka

# Create data directories
sudo mkdir -p /var/lib/kafka
sudo mkdir -p /var/log/kafka
sudo chown -R kafka:kafka /var/lib/kafka
sudo chown -R kafka:kafka /var/log/kafka

echo "✅ Kafka installation completed!"