#!/bin/bash

echo "📊 Kafka Ecosystem Status Check"

echo ""
echo "🔍 Service Status:"
echo "Zookeeper: $(systemctl is-active zookeeper)"
echo "Kafka: $(systemctl is-active kafka)"

echo ""
echo "📈 Service Health:"
sudo systemctl status zookeeper --no-pager -l
echo "---"
sudo systemctl status kafka --no-pager -l

echo ""
echo "🌐 Network Listening Ports:"
sudo netstat -tlnp | grep -E '(2181|9092|29092)'

echo ""
echo "📝 Recent Logs (Kafka):"
sudo journalctl -u kafka --lines=10 --no-pager

echo ""
echo "🦄 Recent Logs (Zookeeper):"
sudo journalctl -u zookeeper --lines=10 --no-pager