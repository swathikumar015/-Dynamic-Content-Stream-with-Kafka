from flask import Flask, render_template, request, jsonify
from database import DatabaseManager
import threading
import time

app = Flask(__name__)
db = DatabaseManager()

@app.route('/')
def index():
    topics = db.get_active_topics()
    subscriptions = db.get_all_subscriptions()
    return render_template('frontend.html', topics=topics, subscriptions=subscriptions)

@app.route('/topics')
def get_topics():
    topics = db.get_active_topics()
    return jsonify([{
        'id': t[0],
        'name': t[1],
        'description': t[2],
        'status': t[3]
    } for t in topics])

@app.route('/subscribe', methods=['POST'])
def subscribe():
    user_id = request.json.get('user_id')
    topic_id = request.json.get('topic_id')
    
    if db.subscribe_user(user_id, topic_id):
        return jsonify({'success': True, 'message': 'Subscribed successfully'})
    else:
        return jsonify({'success': False, 'message': 'Already subscribed'})

@app.route('/unsubscribe', methods=['POST'])
def unsubscribe():
    user_id = request.json.get('user_id')
    topic_id = request.json.get('topic_id')
    
    if db.unsubscribe_user(user_id, topic_id):
        return jsonify({'success': True, 'message': 'Unsubscribed successfully'})
    else:
        return jsonify({'success': False, 'message': 'Subscription not found'})

@app.route('/add_topic', methods=['POST'])
def add_topic():
    name = request.json.get('name')
    description = request.json.get('description', '')
    
    if db.add_topic(name, description):
        return jsonify({'success': True, 'message': 'Topic added successfully'})
    else:
        return jsonify({'success': False, 'message': 'Topic already exists'})

if __name__ == '__main__':
    app.run(debug=True, port=5001)