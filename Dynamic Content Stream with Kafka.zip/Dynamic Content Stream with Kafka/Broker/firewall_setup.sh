#!/bin/bash

echo "🔥 Configuring Firewall for Kafka Broker"

# Enable firewall
sudo ufw enable

# Allow SSH
sudo ufw allow 22

# Allow Kafka ports
sudo ufw allow 9092    # Kafka external
sudo ufw allow 29092   # Kafka internal
sudo ufw allow 2181    # Zookeeper

# Allow admin API if running on this node
sudo ufw allow 5000

# Show firewall status
echo "📊 Firewall Status:"
sudo ufw status verbose

echo "✅ Firewall configured for Kafka!"