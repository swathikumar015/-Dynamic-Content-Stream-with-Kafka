#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

if [ -z "$1" ]; then
    echo "Usage: ./test_consumer.sh <topic-name>"
    echo "Example: ./test_consumer.sh test-topic"
    exit 1
fi

TOPIC_NAME=$1

echo "Starting console consumer for topic: $TOPIC_NAME"
echo "Listening for messages (Ctrl+C to exit):"
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic $TOPIC_NAME --from-beginning