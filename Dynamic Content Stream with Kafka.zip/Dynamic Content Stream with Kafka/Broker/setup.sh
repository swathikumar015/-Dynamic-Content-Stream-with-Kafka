#!/bin/bash

# ============================================
# Complete Kafka Setup for Ubuntu VM
# ============================================

echo "=========================================="
echo "Kafka Broker Setup for Ubuntu VM"
echo "=========================================="

# Get IP addresses
LOCAL_IP="192.168.244.128"
ZEROTIER_IP="172.25.249.190"

echo ""
echo "Your IP Addresses:"
echo "  Local Network (ens33): $LOCAL_IP"
echo "  ZeroTier VPN: $ZEROTIER_IP"
echo ""
echo "For other nodes to connect:"
echo "  - Same local network → $LOCAL_IP:9092"
echo "  - Remote/Different network → $ZEROTIER_IP:9092"
echo ""

# Ask user which IP to use
read -p "Which IP should other nodes use? (1=Local, 2=ZeroTier, 3=Both): " IP_CHOICE

case $IP_CHOICE in
    1)
        ADVERTISED_IP=$LOCAL_IP
        echo "Using Local IP: $LOCAL_IP"
        ;;
    2)
        ADVERTISED_IP=$ZEROTIER_IP
        echo "Using ZeroTier IP: $ZEROTIER_IP"
        ;;
    3)
        ADVERTISED_IP=$LOCAL_IP
        echo "Using Local IP (will configure for both)"
        ;;
    *)
        ADVERTISED_IP=$LOCAL_IP
        echo "Invalid choice, defaulting to Local IP: $LOCAL_IP"
        ;;
esac

# ============================================
# STEP 1: Configure Firewall
# ============================================
echo ""
echo "Configuring Ubuntu Firewall (UFW)..."

sudo ufw status > /dev/null 2>&1
if [ $? -eq 0 ]; then
    sudo ufw allow 9092/tcp
    sudo ufw allow 2181/tcp
    echo "Firewall rules added for ports 9092 and 2181"
else
    echo "UFW not available, skipping firewall configuration"
fi

# ============================================
# STEP 2: Create Directory Structure
# ============================================
echo ""
echo "Creating directory structure..."
cd ~
mkdir -p Machine-A/database
cd Machine-A

# ============================================
# STEP 3: Download and Extract Kafka
# ============================================
echo ""
echo "Downloading Kafka 3.6.0..."
if [ ! -d "kafka_2.13-3.6.0" ]; then
    wget https://downloads.apache.org/kafka/3.6.0/kafka_2.13-3.6.0.tgz
    tar -xzf kafka_2.13-3.6.0.tgz
    rm kafka_2.13-3.6.0.tgz
    echo "Kafka downloaded and extracted"
else
    echo "Kafka already exists, skipping download"
fi

# ============================================
# STEP 4: Configure Kafka Server
# ============================================
echo ""
echo "Configuring Kafka server..."

# Backup original
cp kafka_2.13-3.6.0/config/server.properties kafka_2.13-3.6.0/config/server.properties.backup 2>/dev/null

# Create new configuration
cat > kafka_2.13-3.6.0/config/server.properties << EOF
# Broker Configuration
broker.id=0

# Network Configuration
listeners=PLAINTEXT://0.0.0.0:9092
advertised.listeners=PLAINTEXT://$ADVERTISED_IP:9092

# Topic Configuration
auto.create.topics.enable=false
num.partitions=1
default.replication.factor=1

# Zookeeper Configuration
zookeeper.connect=localhost:2181

# Log Configuration
log.dirs=/tmp/kafka-logs
log.retention.hours=168
log.segment.bytes=1073741824
log.retention.check.interval.ms=300000

# Replication Configuration
offsets.topic.replication.factor=1
transaction.state.log.replication.factor=1
transaction.state.log.min.isr=1

# Group Coordinator Configuration
group.initial.rebalance.delay.ms=0
EOF

echo "Kafka configured with advertised IP: $ADVERTISED_IP:9092"

# ============================================
# STEP 5: Create Database Setup Script
# ============================================
echo ""
echo "Creating database setup script..."

cat > database/db_setup.sql << 'SQLEOF'
-- Database Setup for Kafka Integration
CREATE DATABASE IF NOT EXISTS kafka_demo;
USE kafka_demo;

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic VARCHAR(255) NOT NULL,
    message_key VARCHAR(255),
    message_value TEXT,
    partition_id INT,
    offset_id BIGINT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_topic (topic),
    INDEX idx_timestamp (timestamp)
);

-- User events table
CREATE TABLE IF NOT EXISTS user_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_event_type (event_type)
);

-- Event logs table
CREATE TABLE IF NOT EXISTS event_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_node VARCHAR(50),
    log_level ENUM('INFO', 'WARNING', 'ERROR') DEFAULT 'INFO',
    log_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_source (source_node),
    INDEX idx_created_at (created_at)
);

SELECT 'Database setup completed successfully!' AS status;
SQLEOF

# ============================================
# STEP 6: Create Management Scripts
# ============================================
echo ""
echo "Creating management scripts..."

# Start Kafka Script
cat > start_kafka.sh << 'STARTEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

echo "Starting Zookeeper..."
bin/zookeeper-server-start.sh config/zookeeper.properties > /tmp/zookeeper.log 2>&1 &
echo "Waiting for Zookeeper to start..."
sleep 10

echo "Starting Kafka Server..."
bin/kafka-server-start.sh config/server.properties > /tmp/kafka.log 2>&1 &
echo "Waiting for Kafka to start..."
sleep 10

echo ""
echo "Kafka is running!"
echo "Check status with: ./check_status.sh"
STARTEOF

chmod +x start_kafka.sh

# Stop Kafka Script
cat > stop_kafka.sh << 'STOPEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

echo "Stopping Kafka Server..."
bin/kafka-server-stop.sh
sleep 5

echo "Stopping Zookeeper..."
bin/zookeeper-server-stop.sh
sleep 3

echo "Kafka and Zookeeper stopped"
STOPEOF

chmod +x stop_kafka.sh

# Check Status Script
cat > check_status.sh << 'STATUSEOF'
#!/bin/bash

echo "=== Java Processes ==="
jps

echo ""
echo "=== Your Connection Information ==="
echo "Local Network: 192.168.244.128:9092"
echo "ZeroTier VPN: 172.25.249.190:9092"

echo ""
echo "=== Port Status ==="
sudo netstat -tuln | grep -E "9092|2181" || ss -tuln | grep -E "9092|2181"

echo ""
echo "=== Recent Kafka Logs (last 20 lines) ==="
if [ -f /tmp/kafka.log ]; then
    tail -20 /tmp/kafka.log
else
    echo "Kafka log not found"
fi
STATUSEOF

chmod +x check_status.sh

# Create Topic Script
cat > create_topic.sh << 'TOPICEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

if [ -z "$1" ]; then
    echo "Usage: ./create_topic.sh <topic-name> [partitions] [replication-factor]"
    echo "Example: ./create_topic.sh my-topic 4 1"
    exit 1
fi

TOPIC=$1
PARTITIONS=${2:-1}
REPLICATION=${3:-1}

bin/kafka-topics.sh --create \
    --bootstrap-server localhost:9092 \
    --topic $TOPIC \
    --partitions $PARTITIONS \
    --replication-factor $REPLICATION

echo "Topic '$TOPIC' created with $PARTITIONS partitions"
TOPICEOF

chmod +x create_topic.sh

# List Topics Script
cat > list_topics.sh << 'LISTEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

echo "=== All Kafka Topics ==="
bin/kafka-topics.sh --list --bootstrap-server localhost:9092
LISTEOF

chmod +x list_topics.sh

# Test Producer Script
cat > test_producer.sh << 'PRODEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

if [ -z "$1" ]; then
    echo "Usage: ./test_producer.sh <topic-name>"
    exit 1
fi

echo "Type messages (Ctrl+C to exit):"
bin/kafka-console-producer.sh --bootstrap-server localhost:9092 --topic $1
PRODEOF

chmod +x test_producer.sh

# Test Consumer Script
cat > test_consumer.sh << 'CONSEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

if [ -z "$1" ]; then
    echo "Usage: ./test_consumer.sh <topic-name>"
    exit 1
fi

echo "Listening for messages (Ctrl+C to exit):"
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic $1 --from-beginning
CONSEOF

chmod +x test_consumer.sh

# ============================================
# STEP 7: Create Connection Info File
# ============================================
cat > CONNECTION_INFO.txt << INFOEOF
========================================
KAFKA BROKER CONNECTION INFORMATION
========================================

For the 4 other nodes to connect:

Option 1: Same Local Network (192.168.244.x)
---------------------------------------------
bootstrap.servers=192.168.244.128:9092

Option 2: Remote via ZeroTier VPN
----------------------------------
bootstrap.servers=172.25.249.190:9092

Testing Connection from Other Nodes:
-------------------------------------
# Test if port is accessible
telnet $ADVERTISED_IP 9092

# Or using netcat
nc -zv $ADVERTISED_IP 9092

# Or using Kafka tools
bin/kafka-broker-api-versions.sh --bootstrap-server $ADVERTISED_IP:9092

Configuration for Python Clients:
----------------------------------
from kafka import KafkaProducer, KafkaConsumer

producer = KafkaProducer(
    bootstrap_servers=['$ADVERTISED_IP:9092']
)

consumer = KafkaConsumer(
    'topic-name',
    bootstrap_servers=['$ADVERTISED_IP:9092'],
    auto_offset_reset='earliest'
)

Configuration for Java Clients:
--------------------------------
Properties props = new Properties();
props.put("bootstrap.servers", "$ADVERTISED_IP:9092");
props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

Ports Used:
-----------
- Kafka Broker: 9092
- Zookeeper: 2181 (localhost only)
INFOEOF

# ============================================
# FINAL MESSAGE
# ============================================
echo ""
echo "=========================================="
echo "SETUP COMPLETE!"
echo "=========================================="
echo ""
echo "Directory structure created at: ~/Machine-A/"
echo ""
echo "Management scripts created:"
echo "  ./start_kafka.sh      - Start Kafka and Zookeeper"
echo "  ./stop_kafka.sh       - Stop Kafka and Zookeeper"
echo "  ./check_status.sh     - Check status and connection info"
echo "  ./create_topic.sh     - Create a new topic"
echo "  ./list_topics.sh      - List all topics"
echo "  ./test_producer.sh    - Test message production"
echo "  ./test_consumer.sh    - Test message consumption"
echo ""
echo "Connection Info: See CONNECTION_INFO.txt"
echo ""
echo "Next steps:"
echo "  1. cd ~/Machine-A"
echo "  2. ./start_kafka.sh"
echo "  3. ./create_topic.sh test-topic 4 1"
echo "  4. Share connection info with other nodes"
echo ""
echo "Your Kafka Broker: $ADVERTISED_IP:9092"
echo "=========================================="