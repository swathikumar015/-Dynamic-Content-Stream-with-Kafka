#!/bin/bash

echo "Kafka Broker Setup for ZeroTier Network"
echo "========================================"

# Configure Firewall
echo "Configuring firewall..."
sudo ufw allow 9092/tcp
sudo ufw allow 2181/tcp

# Create directory structure
cd ~
mkdir -p Machine-A/database
cd Machine-A

# Download Kafka
echo "Downloading Kafka..."
if [ ! -d "kafka_2.13-3.6.0" ]; then
    wget https://downloads.apache.org/kafka/3.6.0/kafka_2.13-3.6.0.tgz
    tar -xzf kafka_2.13-3.6.0.tgz
    rm kafka_2.13-3.6.0.tgz
fi

# Configure Kafka for ZeroTier
echo "Configuring Kafka for ZeroTier IP: 172.25.249.190"
cat > kafka_2.13-3.6.0/config/server.properties << 'KAFKAEOF'
broker.id=0
listeners=PLAINTEXT://0.0.0.0:9092
advertised.listeners=PLAINTEXT://172.25.249.190:9092
auto.create.topics.enable=false
zookeeper.connect=localhost:2181
log.dirs=/tmp/kafka-logs
num.partitions=1
default.replication.factor=1
offsets.topic.replication.factor=1
transaction.state.log.replication.factor=1
transaction.state.log.min.isr=1
log.retention.hours=168
log.segment.bytes=1073741824
group.initial.rebalance.delay.ms=0
KAFKAEOF

# Create database script
cat > database/db_setup.sql << 'SQLEOF'
CREATE DATABASE IF NOT EXISTS kafka_demo;
USE kafka_demo;

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic VARCHAR(255) NOT NULL,
    message_key VARCHAR(255),
    message_value TEXT,
    partition_id INT,
    offset_id BIGINT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_topic (topic)
);

CREATE TABLE IF NOT EXISTS user_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
);

CREATE TABLE IF NOT EXISTS event_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_node VARCHAR(50),
    log_level ENUM('INFO', 'WARNING', 'ERROR') DEFAULT 'INFO',
    log_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
SQLEOF

# Create start script
cat > start_kafka.sh << 'STARTEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0
echo "Starting Zookeeper..."
bin/zookeeper-server-start.sh config/zookeeper.properties > /tmp/zookeeper.log 2>&1 &
sleep 10
echo "Starting Kafka..."
bin/kafka-server-start.sh config/server.properties > /tmp/kafka.log 2>&1 &
sleep 10
echo "Kafka is running on ZeroTier: 172.25.249.190:9092"
STARTEOF
chmod +x start_kafka.sh

# Create stop script
cat > stop_kafka.sh << 'STOPEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0
bin/kafka-server-stop.sh
sleep 5
bin/zookeeper-server-stop.sh
echo "Kafka stopped"
STOPEOF
chmod +x stop_kafka.sh

# Create check status script
cat > check_status.sh << 'STATUSEOF'
#!/bin/bash
echo "=== Kafka Status ==="
jps | grep -E "Kafka|QuorumPeer"
echo ""
echo "=== Connection Info ==="
echo "ZeroTier IP: 172.25.249.190:9092"
echo ""
echo "=== Listening Ports ==="
sudo netstat -tuln | grep -E "9092|2181"
STATUSEOF
chmod +x check_status.sh

# Create topic script
cat > create_topic.sh << 'TOPICEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0
if [ -z "$1" ]; then
    echo "Usage: ./create_topic.sh <topic-name> [partitions]"
    exit 1
fi
bin/kafka-topics.sh --create --bootstrap-server localhost:9092 --topic $1 --partitions ${2:-4} --replication-factor 1
TOPICEOF
chmod +x create_topic.sh

# Create list topics script
cat > list_topics.sh << 'LISTEOF'
#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0
bin/kafka-topics.sh --list --bootstrap-server localhost:9092
LISTEOF
chmod +x list_topics.sh

echo ""
echo "=========================================="
echo "SETUP COMPLETE!"
echo "=========================================="
echo "ZeroTier Broker Address: 172.25.249.190:9092"
echo ""
echo "Next steps:"
echo "  cd ~/Machine-A"
echo "  ./start_kafka.sh"
echo ""