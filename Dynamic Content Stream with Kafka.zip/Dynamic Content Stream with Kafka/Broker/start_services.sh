#!/bin/bash

echo "🚀 Starting Kafka Ecosystem Services..."

# Create systemd service for Zookeeper
sudo tee /etc/systemd/system/zookeeper.service << EOF
[Unit]
Description=Apache Zookeeper
After=network.target

[Service]
Type=simple
User=kafka
Group=kafka
ExecStart=/opt/kafka/bin/zookeeper-server-start.sh /opt/kafka/config/zookeeper.properties
ExecStop=/opt/kafka/bin/zookeeper-server-stop.sh
Restart=on-abnormal

[Install]
WantedBy=multi-user.target
EOF

# Create systemd service for Kafka
sudo tee /etc/systemd/system/kafka.service << EOF
[Unit]
Description=Apache Kafka
After=network.target zookeeper.service

[Service]
Type=simple
User=kafka
Group=kafka
ExecStart=/opt/kafka/bin/kafka-server-start.sh /opt/kafka/config/server.properties
ExecStop=/opt/kafka/bin/kafka-server-stop.sh
Restart=on-abnormal

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable services
sudo systemctl daemon-reload
sudo systemctl enable zookeeper
sudo systemctl enable kafka

# Start Zookeeper
echo "🦄 Starting Zookeeper..."
sudo systemctl start zookeeper
sleep 10

# Check Zookeeper status
if sudo systemctl is-active --quiet zookeeper; then
    echo "✅ Zookeeper started successfully!"
else
    echo "❌ Zookeeper failed to start!"
    sudo systemctl status zookeeper
    exit 1
fi

# Start Kafka
echo "📊 Starting Kafka Broker..."
sudo systemctl start kafka
sleep 15

# Check Kafka status
if sudo systemctl is-active --quiet kafka; then
    echo "✅ Kafka started successfully!"
else
    echo "❌ Kafka failed to start!"
    sudo systemctl status kafka
    exit 1
fi

# Display status
echo ""
echo "📊 Service Status:"
echo "Zookeeper: $(sudo systemctl is-active zookeeper)"
echo "Kafka: $(sudo systemctl is-active kafka)"
echo ""
echo "🌐 Kafka Broker is listening on:"
echo "   External: $(hostname -I | awk '{print $1}'):9092"
echo "   Internal: $(hostname -I | awk '{print $1}'):29092"
echo ""
echo "✅ All services are running!"