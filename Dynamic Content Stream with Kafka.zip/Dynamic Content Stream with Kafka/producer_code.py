import threading
import time
import json
import random
from kafka import KafkaProducer, KafkaAdminClient
from kafka.admin import NewTopic
from kafka.errors import TopicAlreadyExistsError
import requests
import socket
from queue import Queue, Empty
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(_name_)

class DistributedProducer:
    def _init_(self, admin_host='172.25.119.229', admin_port=5000, kafka_broker=None):
        self.admin_host = admin_host
        self.admin_port = admin_port
        self.producer_ip = self.get_local_ip()
        
        self.kafka_broker = kafka_broker
        self.producer = None
        self.admin_client = None
        self.message_queue = Queue()
        self.running = True
        
        # Cache for topic descriptions
        self.topic_descriptions = {}
        
        logger.info(f"🔗 Connecting to:")
        logger.info(f"   Admin: {self.admin_host}:{self.admin_port}")
        if self.kafka_broker:
            logger.info(f"   Kafka: {self.kafka_broker} (configured)")
        
        self.initialize_components()
        
        # Sample data - message content for each topic
        self.sample_data = {
            'news': [" World News Update", "Breaking News Alert", " Daily News Digest"],
            'sports': ["Sports Update", " Game Results", " Tournament News", " Tennis Championship"],
            'tech': [" Tech Innovation", "Software Update", " Gadget News"],
            'finance': [" Market Update", " Stock News", " Financial Tips"],
            'entertainment': ["� Movie News", " Music Update", " Entertainment Gossip"],
            'daa': [" Algorithm Analysis", " Data Structures Update", " Performance Optimization Tips", " Complexity Theory Discussion"],
            'cn': [" Network Protocols Explained", " Security Updates", " Connectivity News", " OSI Model Discussion"],
            'mpca': [" Microprocessor News", " Architecture Updates", " Component Analysis", " CPU Design Insights"],
            'ac': [" AC Circuit Analysis", " Power Systems Update", " Electrical Engineering News", "⚙ Circuit Design Tips"],
            'gt': [" Graph Theory Insights", " Network Analysis", " Combinatorics Update", " Tree Algorithms"],
            'ML': [" Machine Learning Update", " AI Research Breakthrough", " ML Model News", " Deep Learning Insights"],
            'phy': [" Physics Concepts", " Quantum Mechanics Update", " Astrophysics News"],
            'ai': [" AI Latest Research", " Neural Networks Update", " AI Applications"],
            'epd': [" Electronics & Power Devices", " Power Electronics Update", " Device Technology News"],
            'da': [" Data Analytics Insights", " Business Intelligence Update", " Data Mining Techniques"],
            
            # Additional topics that might exist in your database
            'test': [" Test Message #1", " Test Update #2", " System Test #3"],
            'newss': [" Latest News Flash", " News Bulletin Update", " Breaking Story"],
            'techieeee': [" Tech Trends Alert", " Innovation Update", " Startup News"],
            'swathi': [" Hello from Swathi topic", " Swathi Update", " Special Message"],
            'ninju': [" Ninju Topic Message", " Ninju Update", " Ninju Content"],
            'bd': [" Big Data Update", " Data Analytics News", " Database Insights"],
            'se': [" Software Engineering", " System Design Patterns", " Development Update"],
            'hello': ["hello", "test messsage", "test message 3"],
        }
        
        # Generic fallback messages for topics without specific data
        self.generic_messages = [
            " Update from {topic}",
            " New content in {topic}",
            " Latest from {topic}",
            " {topic} notification",
            " Message from {topic}"
        ]
    
    def get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except:
            return "127.0.0.1"
    
    def discover_kafka_broker(self):
        """Discover Kafka broker from admin panel"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                logger.info(f"🔍 Discovering Kafka broker from admin (attempt {attempt + 1}/{max_retries})...")
                response = requests.get(
                    f"http://{self.admin_host}:{self.admin_port}/api/kafka_broker",
                    timeout=5
                )
                if response.status_code == 200:
                    data = response.json()
                    if data['status'] == 'success':
                        broker_ip = data['broker_ip']
                        broker_port = data['broker_port']
                        discovered_broker = f"{broker_ip}:{broker_port}"
                        logger.info(f"✅ Discovered Kafka broker: {discovered_broker}")
                        self.kafka_broker = discovered_broker
                        return True
            except Exception as e:
                logger.warning(f"⚠ Discovery attempt {attempt + 1} failed: {e}")
            
            if attempt < max_retries - 1:
                time.sleep(2)
        
        logger.error("❌ Failed to discover Kafka broker from admin")
        return False
    
    def register_producer(self):
        """Register this producer with admin panel"""
        try:
            response = requests.post(
                f"http://{self.admin_host}:{self.admin_port}/api/register_node",
                json={
                    'node_type': 'producer',
                    'node_ip': self.producer_ip,
                    'node_port': None
                },
                timeout=5
            )
            if response.status_code == 200:
                logger.info("✅ Producer registered with admin panel")
                return True
        except Exception as e:
            logger.error(f"❌ Failed to register producer: {e}")
        return False
    
    def test_kafka_connection(self, broker_address):
        """Test if we can reach Kafka at given address"""
        try:
            host, port = broker_address.split(':')
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex((host, int(port)))
            sock.close()
            return result == 0
        except Exception as e:
            logger.error(f"❌ Connection test failed: {e}")
            return False
    
    def initialize_kafka(self):
        """Initialize Kafka connections with retry logic"""
        if not self.kafka_broker:
            logger.error("❌ No Kafka broker available")
            return False
        
        logger.info(f"🔍 Testing connectivity to {self.kafka_broker}...")
        if not self.test_kafka_connection(self.kafka_broker):
            logger.error(f"❌ Cannot reach Kafka broker at {self.kafka_broker}")
            logger.error("   Please check:")
            logger.error("   1. Kafka is running on the broker")
            logger.error("   2. Firewall allows port 9092")
            logger.error("   3. Both machines are on the same network")
            return False
        
        logger.info(f"✅ Can reach {self.kafka_broker}")
            
        max_retries = 3
        for attempt in range(max_retries):
            try:
                logger.info(f"🔄 Initializing Kafka client (attempt {attempt + 1}/{max_retries})...")
                
                self.producer = KafkaProducer(
                    bootstrap_servers=self.kafka_broker,
                    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                    key_serializer=lambda v: v.encode('utf-8') if v else None,
                    request_timeout_ms=30000,
                    api_version_auto_timeout_ms=10000,
                    retries=3
                )
                
                self.admin_client = KafkaAdminClient(
                    bootstrap_servers=self.kafka_broker,
                    request_timeout_ms=30000,
                    api_version_auto_timeout_ms=10000
                )
                
                logger.info(f"✅ Kafka connections established to {self.kafka_broker}")
                return True
            except Exception as e:
                logger.error(f"❌ Kafka initialization attempt {attempt + 1}/{max_retries} failed: {e}")
                if attempt < max_retries - 1:
                    time.sleep(5)
        
        logger.error("❌ All Kafka connection attempts failed")
        return False
    
    def initialize_components(self):
        """Initialize all components"""
        logger.info("🚀 Initializing Distributed Producer...")
        
        if not self.register_producer():
            logger.warning("⚠ Failed to register with admin panel, continuing anyway...")
        
        if not self.kafka_broker:
            if not self.discover_kafka_broker():
                logger.error("❌ Failed to discover Kafka broker")
                return
        
        if not self.initialize_kafka():
            logger.error("❌ Failed to initialize Kafka connections")
            logger.info("🔄 Starting threads with reconnection capability")
        else:
            logger.info("✅ All components initialized successfully")
    
    def get_topics_from_admin(self):
        """Get topic information from admin panel WITH DESCRIPTIONS"""
        try:
            response = requests.get(
                f"http://{self.admin_host}:{self.admin_port}/api/topics",
                timeout=5
            )
            if response.status_code == 200:
                return response.json()
        except Exception as e:
            logger.error(f"❌ Failed to get topics from admin: {e}")
        return None

    def get_active_topics_with_descriptions(self):
        """Get active topics with their descriptions - CRITICAL"""
        try:
            response = requests.get(
                f"http://{self.admin_host}:{self.admin_port}/api/topics",
                timeout=5
            )
            if response.status_code == 200:
                data = response.json()
                # Return dict mapping topic name to description
                topics_with_desc = {}
                for topic in data.get('active', []):
                    topic_name = topic['name']
                    topic_desc = topic.get('description', 'No description')
                    topics_with_desc[topic_name] = topic_desc
                    # Cache the description
                    self.topic_descriptions[topic_name] = topic_desc
                
                if topics_with_desc:
                    logger.info(f"📋 Active topics: {list(topics_with_desc.keys())}")
                return topics_with_desc
        except Exception as e:
            logger.error(f"❌ Failed to get active topics: {e}")
        return {}
    
    def add_topic_request(self, name, description=""):
        """Request a new topic from admin"""
        try:
            response = requests.post(
                f"http://{self.admin_host}:{self.admin_port}/add_topic",
                data={'name': name, 'description': description},
                timeout=5
            )
            if response.status_code == 200:
                logger.info(f"📝 Requested topic: {name}")
                return True
            else:
                logger.warning(f"⚠ Topic request failed for: {name}")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to add topic request: {e}")
            return False

    def input_listener_thread(self):
        """THREAD 1: Input Listener - Receives data and enqueues it"""
        logger.info("🎧 Input Listener Thread started")
        
        while self.running:
            try:
                time.sleep(6)  # Generate messages every 6 seconds
                
                # Get active topics WITH descriptions
                topics_with_desc = self.get_active_topics_with_descriptions()
                if not topics_with_desc:
                    logger.info("📭 No active topics to send data to")
                    continue
                
                logger.info(f"📤 Generating messages for {len(topics_with_desc)} active topics")
                
                # Generate messages for ALL active topics
                messages_generated = 0
                for topic_name, topic_description in topics_with_desc.items():
                    # Get message content
                    if topic_name in self.sample_data:
                        message_content = random.choice(self.sample_data[topic_name])
                    else:
                        message_content = random.choice(self.generic_messages).format(topic=topic_name)
                    
                    # CRITICAL: Include topic name, description, AND message content
                    payload = {
                        'topic': topic_name,
                        'description': topic_description,  # ADDED: Description
                        'message': message_content,        # The actual message content
                        'timestamp': time.time(),
                        'producer_ip': self.producer_ip,
                        'message_id': random.randint(1000, 9999),
                        'source': 'input_listener'
                    }
                    
                    self.message_queue.put(payload)
                    messages_generated += 1
                
                if messages_generated > 0:
                    logger.info(f"📥 Enqueued {messages_generated} messages")
                
            except Exception as e:
                logger.error(f"❌ Error in input listener: {e}")
                time.sleep(5)

    def publisher_thread(self):
        """THREAD 2: Publisher - Reads from queue and publishes to Kafka"""
        logger.info("📤 Publisher Thread started")
        
        while self.running:
            try:
                payload = self.message_queue.get(timeout=2)
                
                if not self.producer:
                    logger.warning("⚠ Kafka producer not available, reconnecting...")
                    if self.initialize_kafka():
                        logger.info("✅ Reconnected to Kafka")
                    else:
                        self.message_queue.task_done()
                        time.sleep(5)
                        continue
                
                self.producer.send(
                    topic=payload['topic'],
                    value=payload,
                    key=payload['topic']  # Don't encode - key_serializer handles it
                )
                self.producer.flush()
                
                logger.info(f"✅ Published to {payload['topic']}: {payload['message']}")
                self.message_queue.task_done()
                
            except Empty:
                continue
            except Exception as e:
                logger.error(f"❌ Publisher error: {e}")
                try:
                    self.message_queue.task_done()
                except:
                    pass
                time.sleep(2)
    
    def topic_watcher_thread(self):
        """THREAD 3: Topic Watcher - Monitors for ACTIVE topics and creates them in Kafka"""
        logger.info("👀 Topic Watcher Thread started")
        created_topics = set()
        
        while self.running:
            try:
                if not self.admin_client:
                    logger.warning("⚠ Admin client not available, reconnecting...")
                    if not self.initialize_kafka():
                        time.sleep(10)
                        continue
                
                # CRITICAL FIX: Get ACTIVE topics (not approved)
                topics_data = self.get_topics_from_admin()
                if topics_data and 'active' in topics_data:
                    active_topics = [topic['name'] for topic in topics_data['active']]
                    
                    if active_topics:
                        logger.info(f"📋 Processing {len(active_topics)} active topics for Kafka creation")
                    
                    for topic in topics_data['active']:
                        topic_name = topic['name']
                        
                        if topic_name not in created_topics:
                            try:
                                new_topic = NewTopic(
                                    name=topic_name,
                                    num_partitions=3,  # Increased for better parallelism
                                    replication_factor=1
                                )
                                self.admin_client.create_topics([new_topic])
                                created_topics.add(topic_name)
                                logger.info(f"🎉 ✅ Created Kafka topic: {topic_name}")
                                time.sleep(0.5)  # Small delay between creations
                            except TopicAlreadyExistsError:
                                logger.info(f"ℹ Topic already exists in Kafka: {topic_name}")
                                created_topics.add(topic_name)
                            except Exception as e:
                                logger.error(f"❌ Error creating topic {topic_name}: {e}")
                
                time.sleep(5)  # Check more frequently (was 10)
                
            except Exception as e:
                logger.error(f"❌ Topic watcher error: {e}")
                time.sleep(5)
    
    def start(self):
        """Start all three producer threads"""
        logger.info("🚀 Starting Distributed Producer...")
        
        input_thread = threading.Thread(target=self.input_listener_thread, daemon=True, name="InputListener")
        publisher_thread = threading.Thread(target=self.publisher_thread, daemon=True, name="Publisher")
        watcher_thread = threading.Thread(target=self.topic_watcher_thread, daemon=True, name="TopicWatcher")
        
        input_thread.start()
        publisher_thread.start()
        watcher_thread.start()
        
        logger.info("✅ All three producer threads started!")
        logger.info("   1. 🎧 Input Listener - Generates messages with topic name + description + content")
        logger.info("   2. 📤 Publisher - Publishes to Kafka")
        logger.info("   3. 👀 Topic Watcher - Creates ACTIVE topics in Kafka")
        
        # Request sample topics
        sample_topics = [
            ('daa', 'Design and Analysis of Algorithms'), 
            ('cn', 'Computer Networks'), 
            ('mpca', 'Microprocessors and Computer Architecture'),
            ('ac', 'Analog Circuits'),
            ('gt', 'Graph Theory'),
            ('ML', 'Machine Learning'),
            ('phy', 'Physics'),
            ('ai', 'Artificial Intelligence'),
            ('epd', 'Electronics and Power Devices'),
            ('da', 'Data Analytics'),
            ('hello', 'hello world'),
        ]
        
        logger.info("\n📝 Requesting sample topics...")
        for name, desc in sample_topics:
            self.add_topic_request(name, desc)
            time.sleep(0.5)
        
        logger.info("\n⏳ Producer running. Topics will be created in Kafka automatically...")
        logger.info("   Press Ctrl+C to stop\n")
        
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("\n🛑 Shutting down producer...")
            self.running = False
            if self.producer:
                self.producer.close()
            if self.admin_client:
                self.admin_client.close()

if _name_ == '_main_':
    # IMPORTANT: Use ZeroTier IP for cross-machine communication
    # Producer machine, Admin machine, Consumer machines, and Broker machine
    # are all on different systems connected via ZeroTier
    producer = DistributedProducer(
        admin_host='172.25.119.229',      # Admin's ZeroTier IP
        admin_port=5000,
        kafka_broker='172.25.249.190:9092'  # Broker's ZeroTier IP (REQUIRED!)
    )
    producer.start()
