#!/bin/bash
cd ~/Machine-A/kafka_2.13-3.6.0

echo "Stopping Kafka Server..."
bin/kafka-server-stop.sh

sleep 5

echo "Stopping Zookeeper..."
bin/zookeeper-server-stop.sh

echo "Kafka and Zookeeper stopped"