#!/bin/bash

KAFKA_HOME="/opt/kafka"
BROKER="localhost:9092"

echo "🔧 Kafka Utilities"

case "$1" in
    list-topics)
        echo "📋 Listing all topics:"
        $KAFKA_HOME/bin/kafka-topics.sh --list --bootstrap-server $BROKER
        ;;
    
    create-topic)
        if [ -z "$2" ]; then
            echo "❌ Usage: $0 create-topic <topic-name>"
            exit 1
        fi
        echo "🎯 Creating topic: $2"
        $KAFKA_HOME/bin/kafka-topics.sh --create \
            --topic "$2" \
            --bootstrap-server $BROKER \
            --partitions 1 \
            --replication-factor 1
        ;;
    
    delete-topic)
        if [ -z "$2" ]; then
            echo "❌ Usage: $0 delete-topic <topic-name>"
            exit 1
        fi
        echo "🗑️ Deleting topic: $2"
        $KAFKA_HOME/bin/kafka-topics.sh --delete \
            --topic "$2" \
            --bootstrap-server $BROKER
        ;;
    
    describe-topic)
        if [ -z "$2" ]; then
            echo "❌ Usage: $0 describe-topic <topic-name>"
            exit 1
        fi
        echo "🔍 Describing topic: $2"
        $KAFKA_HOME/bin/kafka-topics.sh --describe \
            --topic "$2" \
            --bootstrap-server $BROKER
        ;;
    
    produce)
        if [ -z "$2" ]; then
            echo "❌ Usage: $0 produce <topic-name>"
            exit 1
        fi
        echo "📤 Producing to topic: $2 (Ctrl+D to stop)"
        $KAFKA_HOME/bin/kafka-console-producer.sh \
            --topic "$2" \
            --bootstrap-server $BROKER
        ;;
    
    consume)
        if [ -z "$2" ]; then
            echo "❌ Usage: $0 consume <topic-name>"
            exit 1
        fi
        echo "📥 Consuming from topic: $2 (Ctrl+C to stop)"
        $KAFKA_HOME/bin/kafka-console-consumer.sh \
            --topic "$2" \
            --from-beginning \
            --bootstrap-server $BROKER
        ;;
    
    cluster-info)
        echo "🏢 Cluster Information:"
        $KAFKA_HOME/bin/kafka-cluster.sh cluster-id --bootstrap-server $BROKER
        $KAFKA_HOME/bin/kafka-cluster.sh describe --bootstrap-server $BROKER
        ;;
    
    logs)
        echo "📝 Recent Kafka Logs:"
        sudo journalctl -u kafka --lines=20 -f
        ;;
    
    zk-logs)
        echo "🦄 Recent Zookeeper Logs:"
        sudo journalctl -u zookeeper --lines=20 -f
        ;;
    
    reset)
        echo "🔄 Resetting Kafka (DANGER - deletes all data!)"
        read -p "Are you sure? This will delete ALL Kafka data! (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            sudo systemctl stop kafka
            sudo systemctl stop zookeeper
            sudo rm -rf /var/lib/kafka/*
            sudo rm -rf /var/lib/zookeeper/*
            sudo systemctl start zookeeper
            sleep 5
            sudo systemctl start kafka
            echo "✅ Kafka reset completed"
        else
            echo "❌ Reset cancelled"
        fi
        ;;
    
    *)
        echo "Kafka Management Utilities"
        echo "Usage: $0 {list-topics|create-topic|delete-topic|describe-topic|produce|consume|cluster-info|logs|zk-logs|reset}"
        echo ""
        echo "Examples:"
        echo "  $0 list-topics                    # List all topics"
        echo "  $0 create-topic test-topic        # Create a new topic"
        echo "  $0 delete-topic test-topic        # Delete a topic"
        echo "  $0 describe-topic test-topic      # Describe topic details"
        echo "  $0 produce test-topic             # Produce messages to topic"
        echo "  $0 consume test-topic             # Consume messages from topic"
        echo "  $0 cluster-info                   # Show cluster information"
        echo "  $0 logs                           # Show Kafka logs"
        echo "  $0 zk-logs                        # Show Zookeeper logs"
        echo "  $0 reset                          # Reset Kafka (deletes all data)"
        ;;
esac