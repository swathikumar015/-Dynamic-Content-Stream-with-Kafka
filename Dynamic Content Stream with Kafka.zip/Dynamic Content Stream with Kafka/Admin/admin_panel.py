from flask import Flask, render_template, request, jsonify, redirect, url_for
from database import DistributedDatabaseManager
import threading
import time

app = Flask(__name__)
db = DistributedDatabaseManager(host='172.25.119.229')

class AdminPanel:
    def __init__(self):
        self.running = True
    
    def auto_approval_worker(self):
        """Background process for automatic topic approval (for demo)"""
        while self.running:
            try:
                pending_topics = db.get_pending_topics()
                for topic in pending_topics:
                    topic_id, topic_name = topic[0], topic[1]
                    # Auto-approve topics that start with certain prefixes
                    if any(prefix in topic_name.lower() for prefix in ['news', 'sports', 'tech', 'finance']):
                        db.update_topic_status(topic_id, 'approved')
                        print(f"✅ Auto-approved topic: {topic_name}")
                
                time.sleep(15)
            except Exception as e:
                print(f"Error in auto-approval: {e}")
                time.sleep(5)

@app.route('/')
def index():
    try:
        # Get all subscriptions
        subscriptions = db.get_all_subscriptions()
        
        # Get topics by status
        pending_topics = db.get_pending_topics()
        approved_topics = db.get_approved_topics()
        active_topics = db.get_active_topics()
        
        # Convert to list of dictionaries for easier template handling
        pending_list = []
        for topic in pending_topics:
            pending_list.append({
                'id': topic[0],
                'name': topic[1],
                'description': topic[2],
                'status': topic[3],
                'created_at': topic[4]
            })
        
        approved_list = []
        for topic in approved_topics:
            approved_list.append({
                'id': topic[0],
                'name': topic[1],
                'description': topic[2],
                'status': topic[3],
                'created_at': topic[4],
                'approved_at': topic[5] if len(topic) > 5 else None
            })
        
        active_list = []
        for topic in active_topics:
            active_list.append({
                'id': topic[0],
                'name': topic[1],
                'description': topic[2],
                'status': topic[3],
                'created_at': topic[4]
            })
        
        return render_template('admin.html', 
                             subscriptions=subscriptions, 
                             pending_topics=pending_list,
                             approved_topics=approved_list,
                             active_topics=active_list)
    except Exception as e:
        return f"Error loading page: {e}", 500

@app.route('/api/topics')
def get_topics_api():
    """API endpoint to get all topics"""
    try:
        pending = db.get_pending_topics()
        approved = db.get_approved_topics()
        active = db.get_active_topics()
        
        return jsonify({
            'pending': [{'id': t[0], 'name': t[1], 'description': t[2], 'status': t[3]} for t in pending],
            'approved': [{'id': t[0], 'name': t[1], 'description': t[2], 'status': t[3]} for t in approved],
            'active': [{'id': t[0], 'name': t[1], 'description': t[2], 'status': t[3]} for t in active]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/register_node', methods=['POST'])
def register_node():
    """API for nodes to register themselves"""
    try:
        data = request.json
        node_type = data.get('node_type')
        node_ip = data.get('node_ip')
        node_port = data.get('node_port')
        
        if db.register_node(node_type, node_ip, node_port):
            return jsonify({'status': 'success', 'message': 'Node registered'})
        else:
            return jsonify({'status': 'error', 'message': 'Registration failed'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/kafka_broker')
def get_kafka_broker():
    """API for producers/consumers to discover Kafka broker"""
    try:
        broker_info = db.get_kafka_broker_info()
        if broker_info:
            return jsonify({
                'status': 'success',
                'broker_ip': broker_info[0],
                'broker_port': broker_info[1]
            })
        else:
            return jsonify({'status': 'error', 'message': 'No Kafka broker registered'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/approve_topic/<int:topic_id>')
def approve_topic(topic_id):
    try:
        db.update_topic_status(topic_id, 'approved')
        print(f"📋 Admin approved topic ID: {topic_id}")
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error approving topic: {e}", 500

@app.route('/reject_topic/<int:topic_id>')
def reject_topic(topic_id):
    try:
        db.update_topic_status(topic_id, 'rejected')
        print(f"❌ Admin rejected topic ID: {topic_id}")
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error rejecting topic: {e}", 500

@app.route('/activate_topic/<int:topic_id>')
def activate_topic(topic_id):
    """Manual activation"""
    try:
        db.update_topic_status(topic_id, 'active')
        db.mark_topic_as_kafka_created(topic_id)
        print(f"🚀 Manually activated topic ID: {topic_id}")
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error activating topic: {e}", 500

@app.route('/add_topic', methods=['POST'])
def add_topic():
    try:
        name = request.form.get('name')
        description = request.form.get('description', '')
        
        if name:
            if db.add_topic(name, description):
                print(f"📝 Added new topic: {name}")
            else:
                print(f"⚠️ Topic already exists: {name}")
        
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error adding topic: {e}", 500

@app.route('/delete_topic/<int:topic_id>')
def delete_topic(topic_id):
    try:
        if db.delete_topic(topic_id):
            print(f"🗑️ Deleted topic ID: {topic_id}")
        else:
            print(f"❌ Failed to delete topic ID: {topic_id}")
        return redirect(url_for('index'))
    except Exception as e:
        return f"Error deleting topic: {e}", 500

@app.route('/system_status')
def system_status():
    """API endpoint for producers/consumers to check system status"""
    try:
        pending_count = len(db.get_pending_topics())
        approved_count = len(db.get_approved_topics())
        active_count = len(db.get_active_topics())
        subscription_count = len(db.get_all_subscriptions())
        
        return jsonify({
            'status': 'healthy',
            'topics': {
                'pending': pending_count,
                'approved': approved_count,
                'active': active_count
            },
            'subscriptions': subscription_count
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ======== ADD THESE 3 NEW ROUTES ========

@app.route('/api/subscribe', methods=['POST'])
def api_subscribe():
    """API for users to subscribe to topics"""
    try:
        data = request.json
        user_id = data.get('user_id')
        topic_id = data.get('topic_id')
        
        if db.subscribe_user(user_id, topic_id):
            return jsonify({'status': 'success', 'message': 'Subscribed successfully'})
        else:
            return jsonify({'status': 'error', 'message': 'Already subscribed or topic not found'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/unsubscribe', methods=['POST'])
def api_unsubscribe():
    """API for users to unsubscribe from topics"""
    try:
        data = request.json
        user_id = data.get('user_id')
        topic_name = data.get('topic_name')
        
        # First get topic ID from name
        import sqlite3
        conn = sqlite3.connect('streaming_system.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM topics WHERE name = ?", (topic_name,))
        result = cursor.fetchone()
        conn.close()
        
        if result:
            topic_id = result[0]
            if db.unsubscribe_user(user_id, topic_id):
                return jsonify({'status': 'success', 'message': 'Unsubscribed successfully'})
        
        return jsonify({'status': 'error', 'message': 'Subscription not found'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/user_subscriptions/<user_id>')
def api_user_subscriptions(user_id):
    """API to get subscriptions for a specific user"""
    try:
        subscriptions = db.get_user_subscriptions(user_id)
        subscription_list = []
        for sub in subscriptions:
            subscription_list.append({
                'topic_id': sub[0],
                'topic_name': sub[1],
                'description': sub[2],
                'subscribed_at': sub[4] if len(sub) > 4 else None
            })
        return jsonify({'user_id': user_id, 'subscriptions': subscription_list})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ======== END OF NEW ROUTES ========

if __name__ == '__main__':
    admin = AdminPanel()
    # Start auto-approval in background
    approval_thread = threading.Thread(target=admin.auto_approval_worker, daemon=True)
    approval_thread.start()
    
    print("🚀 Starting Admin Panel on http://0.0.0.0:5000")
    print("📡 Listening on all interfaces for node registration")
    app.run(debug=True, port=5000, host='172.25.119.229')