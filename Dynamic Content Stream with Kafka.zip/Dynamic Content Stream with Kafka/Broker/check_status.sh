#!/bin/bash

echo "=== Kafka & Zookeeper Process Status ==="
jps | grep -E "Kafka|QuorumPeer"

echo ""
echo "=== Your Broker Information ==="
WSL_IP=$(ip addr show eth0 | grep "inet\b" | awk '{print $2}' | cut -d/ -f1)
echo "WSL IP Address: $WSL_IP"
echo "Kafka Broker: $WSL_IP:9092"
echo "Zookeeper: localhost:2181"

echo ""
echo "=== Port Listening Status ==="
netstat -tuln | grep -E "9092|2181"

echo ""
echo "=== Recent Kafka Logs ==="
tail -20 /tmp/kafka.log