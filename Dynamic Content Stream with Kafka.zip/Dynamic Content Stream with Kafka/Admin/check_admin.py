import socket
import requests

def check_admin_status():
    print("🔍 Checking Admin Panel Status...")
    
    # Get local IP
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"📍 Your System IP: {local_ip}")
    except:
        local_ip = "127.0.0.1"
        print(f"📍 Your System IP: {local_ip} (localhost)")
    
    # Test connections
    test_urls = [
        f"http://localhost:5000",
        f"http://127.0.0.1:5000", 
        f"http://{local_ip}:5000",
        f"http://192.168.1.13:5000"
    ]
    
    for url in test_urls:
        try:
            response = requests.get(url, timeout=2)
            if response.status_code == 200:
                print(f"✅ ADMIN PANEL FOUND: {url}")
                return url
        except:
            print(f"❌ Not found: {url}")
    
    print("\n❌ Admin panel is not running on any tested URL")
    return None

if __name__ == "__main__":
    check_admin_status()